import { setGlobalOptions } from 'firebase-functions/v2';
import { onRequest } from 'firebase-functions/v2/https';

setGlobalOptions({ region: 'europe-west1' });

export const health = onRequest((req, res) => {
  res.status(200).send('ok');
});
